#!/bin/bash

for file in *.yang
do
	echo $file
	sed -i 's/yang-version 1.1;/\/\/yang-version 1.1;/g' $file

done

