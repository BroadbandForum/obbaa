#!/bin/bash

/opt/dev/sysrepo/build/examples/application_example bbf-qos-filters                       > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-link-table                        > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-ipfix-psamp                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-hardware                         > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-qos-classifiers                   > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-pseudowires                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-xpon                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-ghn                               > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-qos-policies                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-alarms                           > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-vdsl                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-xpongemtcont                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-system                           > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-qos-policer-envelope-profiles     > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-ghs                               > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-interfaces                       > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-qos-policies                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-qos-traffic-mngt                  > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-qos-policing                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-selt                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-l2-dhcpv4-relay                   > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ieee802-dot1x                         > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example ietf-netconf-acm                      > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-hardware-rpf-dpu                  > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-pppoe-intermediate-agent          > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-fast                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-mgmd                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-melt                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-subscriber-profiles               > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-ldra                              > /dev/null 2>&1 &
/opt/dev/sysrepo/build/examples/application_example bbf-l2-forwarding            		  > /dev/null 2>&1 &      
																 
while [ 1 ]; do 
	sleep 60;
done









