#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <signal.h>
#include <inttypes.h>
#include <sysrepo.h>
#include <strings.h>
#include <sysrepo/values.h>

volatile int exit_application = 0;

#define XPATH_MAX_LEN 100

#define YANG_DATE_AND_TIME_SIZE  32
typedef char yangDateAndTime[YANG_DATE_AND_TIME_SIZE];

/* for 'onu-state-change' notification */
static void NetconfAgent_send_onu_state_change_notification(sr_session_ctx_t * session)
{
   int rc = 0;
   sr_val_t        values[10] = { { 0, }, };
   size_t          valueCnt = 0;
   int             i = 0;
   yangDateAndTime timeStr = "";
   char            serialStr[32] = "";
   char            ifNameStr[128] = "";

   values[valueCnt].xpath = "/bbf-xpon-onu-states:onu-state-change/detected-serial-number";
   values[valueCnt].type = SR_STRING_T;
   values[valueCnt].data.string_val = "PTIN01020304";
   valueCnt++;
   values[valueCnt].xpath = "/bbf-xpon-onu-states:onu-state-change/channel-termination-ref";
   values[valueCnt].type = SR_STRING_T;
   values[valueCnt].data.string_val = "data1";
   valueCnt++;
   values[valueCnt].xpath = "/bbf-xpon-onu-states:onu-state-change/onu-state-last-change";
   values[valueCnt].type = SR_STRING_T;
   values[valueCnt].data.string_val = "2019-11-13T00:00:00-00:00";
   valueCnt++;
   values[valueCnt].xpath = "/bbf-xpon-onu-states:onu-state-change/onu-state";
   values[valueCnt].type = SR_IDENTITYREF_T;
   values[valueCnt].data.string_val = "bbf-xpon-onu-types:onu-present";
   valueCnt++;
   rc = sr_event_notif_send(session, "/bbf-xpon-onu-states:onu-state-change", values, valueCnt, SR_EV_NOTIF_EPHEMERAL);
   printf("onu-state-change notification sent rc=%d\n", rc);
   if (SR_ERR_OK != rc) {
      fprintf(stderr, "Error sending notification: %s\n", sr_strerror(rc));
   }
}

/* for 'ietf-alarm' notification */
static void NetconfAgent_send_ietf_alarm_notification(sr_session_ctx_t * session, const char *severity, const char *type_qualifier, const char *resource, const char *alarm_text, const char *type_id)
{
   int rc = 0;
   sr_val_t        values[10] = { { 0, }, };
   size_t          valueCnt = 0;

   values[valueCnt].xpath = "/ietf-alarms:alarm-notification/resource";
   values[valueCnt].type = SR_INSTANCEID_T;
   values[valueCnt].data.instanceid_val = (char *) resource;
   valueCnt++;
   values[valueCnt].xpath = "/ietf-alarms:alarm-notification/alarm-type-id";
   values[valueCnt].type = SR_IDENTITYREF_T;
   values[valueCnt].data.string_val = (char *)type_id;
   valueCnt++;
   values[valueCnt].xpath = "/ietf-alarms:alarm-notification/alarm-type-qualifier";
   values[valueCnt].type = SR_STRING_T;
   values[valueCnt].data.string_val = (char *) type_qualifier;
   valueCnt++;
   values[valueCnt].xpath = "/ietf-alarms:alarm-notification/time";
   values[valueCnt].type = SR_STRING_T;
   values[valueCnt].data.string_val = "2019-07-25T05:51:36+00:00";
   valueCnt++;
   values[valueCnt].xpath = "/ietf-alarms:alarm-notification/alarm-text";
   values[valueCnt].type = SR_STRING_T;
   values[valueCnt].data.string_val =  (char *)alarm_text;
   valueCnt++;
   values[valueCnt].xpath = "/ietf-alarms:alarm-notification/perceived-severity";
   values[valueCnt].type = SR_ENUM_T;
   values[valueCnt].data.enum_val = (char *) severity;
   valueCnt++;

   rc = sr_event_notif_send(session, "/ietf-alarms:alarm-notification", values, valueCnt, SR_EV_NOTIF_EPHEMERAL);
   printf("ietf-alarm notification sent rc=%d\n", rc);
   if (SR_ERR_OK != rc) {
      fprintf(stderr, "Error sending notification: %s\n", sr_strerror(rc));
   }
}


int
main(int argc, char **argv)
{
    sr_conn_ctx_t *connection = NULL;
    sr_session_ctx_t *session = NULL;
    sr_subscription_ctx_t *subscription = NULL;
    int rc = SR_ERR_OK;
    char *module_name = "ietf-interfaces";
    const char *severity = "minor";
    const char *alarm_text = "link failure";
    const char *type_qualifier = " text ";
    const char *resource = " ";
    const char *type_id = "vendor-alarms:los";

    for (int i=1; i<argc; i++ )
    {
       if (0) {}
       else if (!strcasecmp(argv[i],"--help"))
       {
          printf("\n");
          printf("Usage: %s [OPTION] VALUE\n", argv[0]);
          printf("\n");
          printf("These options only take effect on notifications of alarm type!\n");
          printf("\n");
          printf("Options list:\n");
          printf("\n");
          printf("     --severity\n");
          printf("     --alarm-text:\n");
          printf("     --type-qualifier\n");
          printf("     --resource\n");
          printf("     --type-id\n");
          printf("\n");
          return 0;
       }
       else if (!strcasecmp(argv[i],"--severity"))
       {
          if ( (i+1)<argc )
          {
             severity = argv[i+1];
             i++;
          }
       }
       else if (!strcasecmp(argv[i],"--alarm-text"))
       {
          if ( (i+1)<argc )
          {
             alarm_text = argv[i+1];
             i++;
          }
       }
       else if (!strcasecmp(argv[i],"--type-qualifier"))
        {
           if ( (i+1)<argc )
           {
              type_qualifier = argv[i+1];
              i++;
           }
        }
       else if (!strcasecmp(argv[i],"--resource"))
        {
           if ( (i+1)<argc )
           {
              resource = argv[i+1];
              i++;
           }
        }
       else if (!strcasecmp(argv[i],"--type-id"))
         {
            if ( (i+1)<argc )
            {
               type_id = argv[i+1];
               i++;
            }
         }
    }

    printf("Trap simulator\n");
    /* connect to sysrepo */
    rc = sr_connect("example_application", SR_CONN_DEFAULT, &connection);
    if (SR_ERR_OK != rc) {
        fprintf(stderr, "Error by sr_connect: %s\n", sr_strerror(rc));
        goto cleanup;
    }

    /* start session */
    rc = sr_session_start(connection, SR_DS_STARTUP, SR_SESS_DEFAULT, &session);
    if (SR_ERR_OK != rc) {
        fprintf(stderr, "Error by sr_session_start: %s\n", sr_strerror(rc));
        goto cleanup;
    }

    printf("Sending Notification\n");

    /* Uncomment the desired type of notification to send */
    //NetconfAgent_send_onu_state_change_notification(session, severity, type_qualifier, resource, alarm_text, type_id);
    NetconfAgent_send_ietf_alarm_notification(session, severity, type_qualifier, resource, alarm_text, type_id);

    printf("Exiting...\n");

cleanup:
    if (NULL != subscription) {
        sr_unsubscribe(session, subscription);
    }
    if (NULL != session) {
        sr_session_stop(session);
    }
    if (NULL != connection) {
        sr_disconnect(connection);
    }
    return rc;
}
