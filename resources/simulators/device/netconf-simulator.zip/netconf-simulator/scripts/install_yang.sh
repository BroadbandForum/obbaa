#!/bin/bash

cd /yang-data/netconf/yangs/
#these scripts are in the yangs dir
sh _install_modules.sh
sh _install_features.sh
